# viSQL
Scan SQL vulnerability on target site and sites of on server.

# Installation

```
~$ git clone https://github.com/blackvkng/viSQL.git
~$ cd viSQL
~# python2 -m pip install -r requirements.txt
~$ python2 viSQL.py --help
```

# Usage

![alt tag](https://i.hizliresim.com/ZEW7kk.png)

# Screenshot

![alt tag](https://i.hizliresim.com/BAEDPD.png)